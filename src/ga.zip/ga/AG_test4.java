package ga;

import ga.objects.Solucion;
import ga.PoblacionInicial;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ysapy on 25/02/16.
 */
public class AG_test4 {

    PoblacionInicial pi = new PoblacionInicial();
    List<Solucion> poblacionInicial = new ArrayList<Solucion>();


}
